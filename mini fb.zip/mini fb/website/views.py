from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify,session
from flask_login import login_required, current_user
from flask_wtf import FlaskForm
from wtforms import FileField
from .models import Post, User, Comment, Like ,Friendship
from . import db
import os
# from flask_uploads import UploadSet, IMAGES, configure_uploads
# from werkzeug.utils import secure_filename


views = Blueprint("views", __name__)
# photos = UploadSet('photos', IMAGES)

# views.config['UPLOADED_PHOTOS_DEST'] = 'path/to/upload/folder'
# views.config['UPLOADED_PHOTOS_ALLOW'] = set(['png', 'jpg', 'jpeg', 'gif'])
# # configure_uploads(views, photos)


@views.route("/")
@views.route("/home")
@login_required
def home():
    posts = Post.query.all()
    return render_template("home.html", user=current_user, posts=posts)


@views.route("/create-post", methods=['GET', 'POST'])
@login_required 
def create_post():
    if request.method == "POST":
        text = request.form.get('text')

        if not text:
            flash('Post cannot be empty', category='error')
        else:
            post = Post(text=text, author=current_user.id)
            db.session.add(post)
            db.session.commit()
            flash('Post created!', category='success')
            return redirect(url_for('views.home'))

    return render_template('create_post.html', user=current_user)


@views.route("/delete-post/<id>")
@login_required
def delete_post(id):
    post = Post.query.filter_by(id=id).first()

    if not post:
        flash("Post does not exist.", category='error')
    # elif current_user.id != post.id:
    #     flash('You do not have permission to delete this post.', category='error')
    else:
        db.session.delete(post)
        db.session.commit()
        flash('Post deleted.', category='success')

    return redirect(url_for('views.home'))


@views.route("update-post/<id>", methods=['GET', 'POST'])
@login_required 
def update_post(id):
    post = Post.query.filter_by(id=id).first()
    if request.method == 'POST':
        if post:
            text = request.form['text']
            if not text:
              flash('Post cannot be empty', category='error')
            
            else:
             post.text = text
             db.session.commit()
             flash('Post updated!', category='success')
            
            
        return redirect(url_for('views.home', user=current_user.id))  
    return render_template('update_post.html', post=post, user=current_user)






@views.route("/posts/<username>")
@login_required
def posts(username):
    user = User.query.filter_by(username=username).first()

    if not user:
        flash('No user with that username exists.', category='error')
        return redirect(url_for('views.home'))

    posts = user.posts
    return render_template("posts.html", user=current_user, posts=posts, username=username)


@views.route("/create-comment/<post_id>", methods=['POST'])
@login_required
def create_comment(post_id):
    text = request.form.get('text')

    if not text:
        flash('Comment cannot be empty.', category='error')
    else:
        post = Post.query.filter_by(id=post_id)
        if post:
            comment = Comment(
                text=text, author=current_user.id, post_id=post_id)
            db.session.add(comment)
            db.session.commit()
        else:
            flash('Post does not exist.', category='error')

    return redirect(url_for('views.home'))


@views.route("/delete-comment/<comment_id>")
@login_required
def delete_comment(comment_id):
    comment = Comment.query.filter_by(id=comment_id).first()

    if not comment:
        flash('Comment does not exist.', category='error')
    elif current_user.id != comment.author and current_user.id != comment.post.author:
        flash('You do not have permission to delete this comment.', category='error')
    else:
        db.session.delete(comment)
        db.session.commit()

    return redirect(url_for('views.home'))


@views.route("/like-post/<post_id>", methods=['GET'])
@login_required
def like(post_id):
    post = Post.query.filter_by(id=post_id).first()
    like = Like.query.filter_by(
        author=current_user.id, post_id=post_id).first()

    if not post:
        flash('post doesnot exist',category = 'error', )
    elif like:
        db.session.delete(like)
        db.session.commit()
    else:
        like = Like(author=current_user.id, post_id=post_id)
        db.session.add(like)
        db.session.commit()

    return redirect(url_for('views.home'))

@views.route("/send-friend-request", methods=['GET', 'POST'])
@login_required 
def send_friend_request():
    if request.method == "POST":
        username = request.form.get('username')

        if not username:
            flash('Username cannot be empty', category='error')
        else:
            user = User.query.filter_by(username=username).first()
            if not user:
                flash('User does not exist.', category='error')
            elif current_user.id == user.id:
                flash('You cannot send a friend request to yourself.', category='error')
            elif current_user in user.friends:
                flash('You are already friends with this user.', category='error')
            else:
                friendship = Friendship(user_id=current_user.id, friend_id=user.id)
                db.session.add(friendship)
                db.session.commit()
                flash('Friend request sent!', category='success')
                return redirect(url_for('views.home'))

    return render_template('send_friend_request.html', user=current_user)





@views.route('/friend-request-response/<int:request_id>', methods=['POST'])
@login_required
def friend_request_response(request_id):

    friend_request = Friendship.query.filter_by(id=request_id).first()

    if friend_request is None:
        flash('Friend request does not exist.', category='error')
        return redirect(url_for('views.home'))

    if current_user != friend_request.receiver:
        flash('You do not have permission to respond to this friend request.', category='error')
        return redirect(url_for('views.home'))

    status = request.form.get('status')

    if status == 'accept':
        friend_request.status = 'accepted'
        current_user.friends.append(friend_request.sender)
        db.session.commit()
        flash('Friend request accepted!', category='success')
        return redirect(url_for('views.home'))

    elif status == 'reject':
        friend_request.status = 'rejected'
        db.session.commit()
        flash('Friend request rejected.', category='success')
        return redirect(url_for('views.home'))



        

@views.route('/navbar-link')
@login_required
def navbar_link():
    friend_requests = Friendship.query.filter_by(receiver=current_user, status='pending').all()

    return render_template('friend_request_response.html', user=current_user, friend_requests=friend_requests)



@views.route("/friends")
@login_required
def friends():
    
    friends = current_user.friends.all()
    return render_template("friends.html", user=current_user, friends=friends, status = 'approved')


# @views.route("/friends")
# @login_required
# def friends():
    
#     # Get all users who have sent friend requests to the current user that have been approved
#     received_friendships = Friendship.query.filter_by(friend_id=current_user.id, status='approved').all()
#     accepted_friends = [friendship.user for friendship in received_friendships]

#     # Get all users who the current user has sent friend requests to that have been approved
#     sent_friendships = Friendship.query.filter_by(user_id=current_user.id, status='approved').all()
#     sent_friends = [friendship.friend for friendship in sent_friendships]

#     # Combine the two lists to get all friends of the current user
#     friends = accepted_friends + sent_friends

#     return render_template("friends.html", user=current_user, friends=friends, status='approved')






@views.route("/delete-friend/<username>", methods=["POST"])
@login_required
def delete_friend(username):
    user = User.query.filter_by(username=username).first()

    if not user:
        flash(f"{username} is not a valid user.", category="error")
        return redirect(url_for("views.home"))

    friendship = Friendship.query.filter(
        (Friendship.user_id == current_user.id) &
        (Friendship.friend_id == user.id)
    ).first()


    db.session.delete(friendship)
    db.session.commit()
    flash(f"You are no longer friends with {username}.", category="success")

    return redirect(url_for("views.friends", username=current_user.username))



     
                                                                                                                                                                                                                                                                                        
    


    
    

    





